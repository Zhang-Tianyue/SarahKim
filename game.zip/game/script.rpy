﻿# 游戏的脚本可置于此文件中。

# 声明此游戏使用的角色。颜色参数可使角色姓名着色。

define n = Character(None)
define js = Character("金莎拉",color="d6b46a")
define aide = Character("助手",color="9db7ff")
define audio.main_bgm="audio/main_bgm.mp3"

image cover bardoir = "images/cover_bardoir.png"
image bg luxury_corridor = "images/bg_luxury_corridor.png"
image bg factory_packaging = "images/bg_factory_packaging.png"
image bg river_despair="images/bg_river_despair.png"
image bg underwater_rebirth = "images/bg_underwater_rebirth.png"
image jin normal ="images/jin_normal.png"
image jin left ="images/jin_left.png"
image bg case2="images/bg_case2.png"
image bg case3 kol="images/bg_case3_kol.png"
image bg case3 private="images/bg_case3_private.png"
image bg case3 clear="images/bg_case3_clear.png"
image bg case4 presale="images/bg_case4_presale.png"
image bg case4 clear="images/bg_case4_clear.png"
image bg case4 interaction="images/case4_interaction.png"

transform bg_full:
    xalign 0.5
    yalign 0.5
    xysize(config.screen_width,config.screen_height)
transform jin_right:
    xalign 0.92
    yalign 1.0
    zoom 0.45
transform jin_center:
    xalign 0.5
    yalign 1.0
    zoom 0.9
transform jin_left_pos:
    xalign 0.10
    yalign 1.0
    zoom 0.52
screen case1_result_table():
    frame:
        xalign 0.5
        ypos 580
        xsize 900
        background Solid("#1f1a14")
        padding(28,22)

        vbox:
            spacing 10
            text"产品定位评级效果" xalign 0.5 size 30 color"#f6e7c8" bold True
            text"量表：1=中端品牌，5=顶奢品牌"xalign 0.5 size 22 color"#d8c7a3"
            vbox:
                spacing 6
                xalign 0.5

                hbox:
                    spacing 6

                    frame:
                        xsize 250
                        ysize 55
                        background Solid("#3a2d1d")
                        text"历史感/进口身份"xalign 0.5 yalign 0.5 size 22 color"#f6e7c8"
                    
                    frame:
                        xsize 220
                        ysize 55
                        background Solid("#3a2d1d")
                        text"本土品牌"xalign 0.5 yalign 0.5 size 24 color"#f6e7c8"
                    frame:
                        xsize 220
                        ysize 55
                        background Solid("#3a2d1d")
                        text"进口品牌"xalign 0.5 yalign 0.5 size 24 color"#f6e7c8"
                hbox:
                    spacing 6
                    frame:
                        xsize 250
                        ysize 55
                        background Solid("#2a2118")
                        text"低历史感"xalign 0.5 yalign 0.5 size 24 color"#f6e7c8"
                    frame:
                        xsize 220
                        ysize 55
                        background Solid("#2a2118")
                        text"2.2"xalign 0.5 yalign 0.5 size 28 color"#ffffff"
                    frame:
                        xsize 220
                        ysize 55
                        background Solid("#2a2118")
                        text"3.1"xalign 0.5 yalign 0.5 size 28 color"#ffffff"
                hbox:
                    spacing 6
                    frame:
                        xsize 250
                        ysize 55
                        background Solid("#2a2118")
                        text"高历史感"xalign 0.5 yalign 0.5 size 24 color"#f6e7c8"
                    frame:
                        xsize 220
                        ysize 55
                        background Solid("#2a2118")
                        text"2.8"xalign 0.5 yalign 0.5 size 28 color"#ffffff"
                    frame:
                        xsize 220
                        ysize 55
                        background Solid("#2a2118")
                        text"4.6"xalign 0.5 yalign 0.5 size 28 color"#ffffff"
screen case2_rt_table():
    frame:
        xalign 0.5
        ypos 580
        xsize 980
        background Solid("#1f1a14")
        padding(28,22)

        vbox:
            spacing 10

            text"正式实验结果"xalign 0.5 size 30 color "#f6e7c8" bold True
            text"任务：尽快判断该虚拟品牌是否属于奢侈品"xalign 0.5 size 22 color"#d8c7a3"
            vbox:
                spacing 6
                xalign 0.5

                hbox:
                    spacing 6
                    frame:
                        xsize 380
                        ysize 60
                        background Solid("#3a2d1d")
                        text"条件"xalign 0.5 yalign 0.5 size 24 color "#f6e7c8"
                    frame:
                        xsize 220
                        ysize 60
                        background Solid("#3a2d1d")
                        text"正确率"xalign 0.5 yalign 0.5 size 24 color "#f6e7c8"
                    frame:
                        xsize 260
                        ysize 60
                        background Solid("#3a2d1d")
                        text"正确反应时"xalign 0.5 yalign 0.5 size 24 color "#f6e7c8"
                hbox:
                    spacing 6
                    frame:
                        xsize 380
                        ysize 60
                        background Solid("#2a2118")
                        text"英国进口叙事"xalign 0.5 yalign 0.5 size 23 color "#f6e7c8"
                    frame:
                        xsize 220
                        ysize 60
                        background Solid("#2a2118")
                        text"82%"xalign 0.5 yalign 0.5 size 28 color "#ffffff"
                    frame:
                        xsize 260
                        ysize 60
                        background Solid("#2a2118")
                        text"1360ms"xalign 0.5 yalign 0.5 size 28 color "#ffffff"
                hbox:
                    spacing 6
                    frame:
                        xsize 380
                        ysize 60
                        background Solid("#2a2118")
                        text"英国进口叙事+可见进口凭证"xalign 0.5 yalign 0.5 size 21 color "#f6e7c8"  
                    frame:
                        xsize 220
                        ysize 60
                        background Solid("#2a2118")
                        text"91%"xalign 0.5 yalign 0.5 size 28 color "#ffffff"
                    frame:
                        xsize 260
                        ysize 60
                        background Solid("#2a2118")
                        text"980ms"xalign 0.5 yalign 0.5 size 28 color "#ffffff"

screen case4_interaction_screen():
    frame:
        xalign 0.5
        ypos 580
        xsize 1050
        ysize 620
        background Solid("#1f1a14")
        padding(22,20)

        vbox:
            spacing 12

            text"Velora预购活动结果"xalign 0.5 size 30 color"#f6e7c8" bold True

            add "images/case4_interaction.png":
                xalign 0.5
                xysize(960,460)

            text"因变量：平均购买意愿强度"xalign 0.5 size 22 color"#d8c7a3"






# 游戏在此开始。

label start:

    # 显示一个背景。此处默认显示占位图，但您也可以在图片目录添加一个文件
    # （命名为 bg room.png 或 bg room.jpg）来显示。

    scene cover bardoir at bg_full with fade
    play music main_bgm fadein 2.0 volume 0.45
    pause 5.0
    n"这是金莎拉创造芭朵奥之前的故事"

    scene bg luxury_corridor at bg_full with fade
    n"金莎拉十八岁，贫穷，却比任何人都更懂奢侈品。"
    n"她出生在买不起奢侈品的家庭，却像信徒研究圣经一样研究着各个国际顶奢。"
    n"高中一毕业，她便凭着近乎偏执的热爱和丰富的奢侈品知识进入 Prada，成为一名柜姐。"
    n"每天站在 Prada 的灯光下，她却总会望向对面 Dior 橱窗里那只她最爱的包——"
    n"那是她触碰不到的梦，是玻璃后的一顶王冠。"
   
    scene bg factory_packaging at bg_full with fade
    n"可命运很快撕碎了她的体面。"
    n"某天，她只是去了一趟洗手间，Prada 的商品就在店里失窃。她被迫背上几十万债款。"
    n"为了还钱，她借下高利贷；还款日到来时，债主闯进 Prada 闹事，她失去了柜姐的工作，只能被赶去工厂处理包装。"
    n"她以为自己已经跌到最底。可命运连最后一点喘息都没有留给她。"
    n"一次拆包时，她不小心划破了包装内的包。那道划痕很轻，却像一把刀再次划开她的人生——"
    n"因为这意味着，她又要赔一笔她根本赔不起的钱。"

    scene bg river_despair at bg_full with fade
    n"她曾经隔着橱窗仰望奢侈品，后来站在柜台后替别人递上奢侈品，最后却连触碰它的资格都被剥夺。"
    n"所有灯光、香气、皮革与微笑，都变成了压在她身上的仿佛永远无法还清的债务。"
    n"绝望之中，金莎拉砸碎了Dior的橱窗。"
    n"她抱起那只梦寐以求的包，像抱起自己最后的尊严，走向河边，带着它一同沉入水中。"

    scene bg underwater_rebirth at bg_full with fade
    n"可在濒死之际，她抬头看见那只包在水光里摇晃。"
    n"那不是死亡的召唤，那是她这一生璀璨耀眼的梦。"
    show jin left at jin_left_pos with dissolve
    js"我不能就这么死去"
    js"我要活下来"
    js"我要亲手创造自己的奢侈品牌"
    hide jin left with dissolve
    n"从那一刻起，一个新的奢侈品牌在她心中诞生了。"
    n"{size=+18}{b}Bardoir,芭朵奥。{/b}{/size}"

    image bg case1 vip="images/bg_case1_vip.png"

label chapter_1:
    scene bg case1 vip at bg_full with fade
    n"金莎拉为自己打造了一个新的身份和简历并成为了Gucci的柜姐，她决定为芭朵奥真正问世做好充分准备。"
    n"金莎拉先设计了40个虚拟包袋品牌，用实验寻找“顶奢定位”背后的心理规律。"
    n"她操纵两个自变量，分别是历史感（近年创立/百年品牌）和进口身份（本土品牌，舶来品牌）"
label case1_q1:
    n"金莎拉决定邀请自己奢侈品店里的客户参加实验。这些客户更接近未来芭朵奥的目标消费人群，但也带来两个麻烦"
    n"一方面，客户群体本身很少，而且大多行程紧张，不可能长时间坐下来评价几十个品牌"
    n"另一方面，这些客户之间差异很大：有人长期购买高奢，有人只是偶尔消费；有人偏爱进口品牌，有人更看重工艺本身；有人对“百年传承”特别敏感，有人更在意设计感。"
    n"金莎拉准备用40个虚拟包袋品牌，考察“历史感”和“进口身份”如何影响客户对品牌的产品定位评级。最合适的总体设计是："
    menu:
        "A.2×2完全被试间设计":
            n"金莎拉皱了皱眉"
            n"这个方案还不能支撑她想要的实验判断"
            jump case1_q1
        "B.2×2完全被试内设计":
            n"这个方案似乎还存在问题"
            jump case1_q1
        "C.2×2不完全被试内设计":
            n"这个设计既避免了个体差异大的问题，也能解决客户不能长时间评价几十个品牌的困难"
            n"金莎拉决定采用这种设计类型"
            jump case1_q2
        "D.2×2混合设计":
            n"这个方案还不是最合适的选择"
            jump case1_q1
label case1_q2:
    scene bg case1 vip at bg_full with fade
    n"为了让实验更接近真实消费场景，金莎拉没有把客户带进普通实验室，而是安排在奢侈品店的贵宾休息区。"
    n"她让店员朋友按照平时接待VIP客户的方式介绍这些虚拟品牌：客户坐下后，店员递上品牌册，简要讲解品牌故事"
    n"一开始，金莎拉觉得这样很好，因为店内接待更自然，生态效度更高。"
    n"但问题很快出现：店员本来就熟悉奢侈品销售话术。她们看到“欧洲百年工坊”“意大利进口”“巴黎沙龙晚宴”这类材料时，会下意识地用更郑重、更欣赏的语气介绍。"
    n"如果继续采用这种流程，最可能出现的问题是："
    menu:
        "A.霍桑效应":
            n"这个判断还不够准确，霍桑效应是需求特征"
            jump case1_q2
        "B.皮格马利翁效应":
            n"店员看到“百年传统 + 进口身份线索”时，本身就会期待这些品牌更像顶奢，于是在语气、停顿、表情、补充说明上无意中传递这种期待。"
            n"客户接收到这些暗示后，可能把这些品牌评得更高。"
            jump case1_q3
        "C.安慰剂效应":
            n"这个选择似乎偏离了真正的问题"
            jump case1_q2
        "D.天花板效应":
            n"现在的问题还不是量表顶端或底部被挤满"
            jump case1_q2
label case1_q3:
    scene bg case1 vip at bg_full with fade
    n"预实验后，金莎拉发现一个问题："
    n"“有进口身份线索”的虚拟品牌，常常不仅写了“欧洲工坊最终工序”，还更容易配上冷色调图片、精致排版、类似法语或意大利语的品牌名、克制疏离的文案语气。"
    n"也就是说，进口身份线索可能和一组模糊的“高级感氛围”绑在一起。"
    n"如果不处理，最后产品定位评级更高，可能不是因为“进口身份线索”本身，而是因为这些品牌整体更像真奢牌。"
    n"金莎拉最合理的控制方式是："
    menu:
        "A.前测四类材料的整体高级感，并使四类均值完全相等。":
            n"这个方案似乎在可行性方面还存在问题"
            jump case1_q3
        "B.对价格、图片、字数等明确因素进行恒定之后随机分配材料":
            n"明确的混淆变量可以采用恒定法，但是“高级感氛围”这种模糊的混淆变量就需采用随机法进行控制"
            jump case1_q4
        "C.进口组统一用欧式视觉，本土组统一用本土视觉，提高真实感。":
            n"提高了生态感，但会把“进口身份线索”和“欧式视觉风格”混在一起，反而损害内部效度。"
            jump case1_q3
        "D.保留材料自然差异，正式实验后使用统计控制法。":
            n"可以作为补充，但统计控制是事后补救，不能替代材料制作阶段的控制。"
            jump case1_q3
label case1_q4:
    scene bg case1 vip at bg_full with fade
    n"正式实验结束后，产品定位评级结果如下："
    show screen case1_result_table
    n"这组结果最合理的效应解读是："
    menu:
        "A.仅历史感主效应":
            hide screen case1_result_table
            n"金莎拉摇了摇头"
            jump case1_q4
        "B.仅进口身份主效应":
            hide screen case1_result_table
            n"金莎拉摇了摇头"
            jump case1_q4
        "C.双主效应，无交互":
            hide screen case1_result_table
            n"金莎拉摇了摇头"
            jump case1_q4
        "D.双主效应，有交互效应":
            hide screen case1_result_table
            n"金莎拉看着结果，脸上露出一点笑意"
            jump case1_clear
label case1_clear:
    scene bg case1 vip at bg_full with fade
    n"金莎拉合上实验记录"
    n"她终于明白，顶奢感不是凭空出现的。单纯贴上进口身份或编造百年历史，只能制造一层短暂的光晕"
    n"真正能撬动客户判断的，是二者被同时编织在一起的童话"
    n"于是，金莎拉做出了决定。"
    n"未来打造芭朵奥时，不能只编百年历史，也不能只贴进口身份，而要把二者绑定起来"
    n"但事情并非这么简单"
    jump chapter_2

label chapter_2:
    scene bg case2 at bg_full with fade
    n"金莎拉还不确定一件事：只在品牌故事里写“英国进口”“欧洲工坊”够不够？"
    n"还是必须让消费者看到更正式、更可验证的进口凭证？"
    n"于是，她决定设计第二轮实验，专门考察：进口凭证是否会让消费者更快、更准确地把品牌判断为奢侈品"
    n"金莎拉准备了一批虚拟包袋品牌材料。这些材料来自真实奢侈品牌和真实非奢侈品牌的改写版本，但全部去掉原品牌名和 logo，重新命名，并在不影响实质的情况微调信息。"
    n"实验中，每个试次呈现一个虚拟品牌。"
    n"被试需要尽快判断：这个品牌是否属于奢侈品？金莎拉记录两个指标：判断正确率、正确反应时"
    n"本案例主要比较两个条件：英国进口叙事、英国进口叙事+进口凭证，其中进口凭证指进口标签、进口条形码等有力进口证据"
    jump case2_q1

label case2_q1:
    scene bg case2 at bg_full with fade
    n"金莎拉先做了一轮试测。"
    n"每名被试在两个条件下各完成 6个试次，两个条件分别是甲：英国进口叙事；乙：英国进口叙事 + 可见进口凭证。"
    n"任务是尽快判断：这个品牌是否属于奢侈品？"
    n"试测数据中出现了几种情况：有些反应时只有 80ms、120ms，有些反应时超过 6000ms，有些被试反应很快，但错误率较高。"
    n"如果要把这个任务改成正式实验，最合理的方案是："
    menu:
        "A.每条件仍做6个试次，剔除过快和过慢反应，比较剩余正确反应时。":
            n"这个实验方案似乎仍有缺陷"
            jump case2_q1
        "B.增加每条件试次数，预设无效数据的标准，分析正确反应时并报告正确率。":
            n"金莎拉点了点头。反应时的噪音较大因此需要较多的试次测量，过快过慢和反应错误的反应时也不应保留为最终数据"
            jump case2_q2
        "C.保留所有正确反应，取反应时的中位数，减少极端值影响。":
            n"这个实验设计似乎仍有缺陷"
            jump case2_q1
        "D. 保留过快和过慢反应，用正确率说明被试是否认真作答。":
            n"这个实验设计似乎仍有缺陷"
            jump case2_q1

label case2_q2:
    scene bg case2 at bg_full with fade
    n"数据分析前，金莎拉已经剔除了低于200ms的抢跑试次、错误反应试次和明显过长的走神试次。结果如表格所示："
    show screen case2_rt_table
    n"于是金莎拉得出结论：没有进口凭证时，被试比有进口凭证时慢了380ms。这说明无凭证条件下，消费者多经历了一个‘确认进口身份是否可信’的心理过程；按照减数法，这个过程的耗时就是380ms。"
    n"对这句话最恰当的评价是："
    menu:
        "A.正确，两个条件的区别只是有无进口凭证，因此反应时的差值就是额外心理过程耗时。":
            hide screen case2_rt_table
            n"这个结论似乎下得有些草率"
            jump case2_q2
        "B.不严谨，差值说明整体判断更慢，但不能直接分离出一个独立心理过程。":
            hide screen case2_rt_table
            n"唐德斯减数法要求两个任务之间只差一个明确、可分离的心理过程。"
            n"本题中，“无凭证”和“有凭证”虽然都要求判断是否为奢侈品，但凭证改变的是整个判断过程中的证据强度和判断确定性，而不一定是简单增加或减少一个孤立阶段。"
            n"因此这个结论并不严谨，金莎拉意识到了这一数据只能反映有进口凭证能提高奢侈品认同的速度与流畅性"
            jump case2_clear
        "C.错误，因为有凭证组正确率更高，所以反应时差异不能再解释。":
            hide screen case2_rt_table
            n"这个解读不太合理"
            jump case2_q2
        "D. 若在实验中匹配两个条件的文字长度、图片大小、呈现位置、颜色显著性和按键方式，就能按减数法解释380ms。":
            hide screen case2_rt_table
            n"条件恒定似乎不是减数法的充分条件"
            jump case2_q2

label case2_clear:
    scene bg case2 at bg_full with fade
    n"金莎拉终于明白：只写“英国进口”确实有用,但还不足以真正把品牌包装成国际顶奢品牌。"
    n"于是，她不再满足于给芭朵奥编一个“英国进口”的故事。"
    n"她开始设计一条更隐秘也更昂贵的路径:"
    n"先将小工坊制作的包身、链条和金属件作为部件低价卖至英国"
    n"由英国合作工坊完成加工、组装后，再让成品以“国际顶奢”的身份高价回到韩国市场"
    n"从这一刻起，芭朵奥真正成为了国际品牌"
    jump chapter_3
label chapter_3:
    scene bg case3 kol at bg_full with fade
    n"金莎拉还没有正式推出芭朵奥。她希望找到让品牌真正地被富人认可为顶奢的方式。"
    n"由于她有一个关系很好的男模朋友，因此知道许多富婆都会私下找男模"
    n"这让她意识到，这也许是一个很不错的方法。也许，芭朵奥可以通过这种路径，被送进真正高净值女性的生活里"
    n"但为了不让芭朵奥提前暴露，她先虚构了一个单一目标测试品牌——Velora，一个高价小众预约制的新锐时尚品牌"
    n"她决定以这个品牌为实验材料开展实验"
    n"这一次，她关注的两种品牌传输路径分别是：自然知晓和私域传播"
    n"为了操纵自然知晓变量，白天，金莎拉会在与客户私下沟通时，不经意提起Velora是个小众顶奢，并分享刷到的KOL热帖"
    scene bg case3 private at bg_full with fade
    n"夜间，在私人陪伴场景中，男模则会对被试提及或不提及Velora"
    n"几天后，金莎拉再通过自然聊天记录她们对Velora的反应"
    jump case3_q1

label case3_q1:
    scene bg case3 kol at bg_full with fade
    n"金莎拉这次只使用同一个目标测试品牌 VELORA作为实验材料展开实验。"
    n"她想同时了解自然知晓和私域传播对提升品牌定位认可度的作用及交互作用"
    n"因此最合适的设计是："
    menu:
        "A.单因素被试间设计":
            n"金莎拉摇了摇头，她还想了解交互作用"
            jump case3_q1
        "B.2×2被试间设计":
            n"金莎拉点了点头，由于只有一个实验材料，为了避免学习效应，只能采用被试间设计"
            jump case3_q2
        "C.2×2完全被试内设计":
            n"这个选择似乎并不稳妥"
            jump case3_q1
        "D.2×2不完全被试内设计":
            n"这个选择似乎并不稳妥"
            jump case3_q1

label case3_q2:
    scene bg case3 kol at bg_full with fade
    n"这次试验只是为之后宣传芭朵奥做准备，不能大规模地铺开 VELORA的宣传，因此她准备只对较少量的客户进行实验。"
    n"金莎拉平时有将客户的各类信息统一记录在笔记本上的习惯，因此充分掌握了客户对奢侈品的喜好等信息。"
    n"针对自然知晓变量，实验最合适的分组方式是:"
    menu:
        "A.将被试随机分入两种水平":
            n"这种操作似乎不符合实验设计的要求"
            jump case3_q2
        "B.先严格匹配，再分为两组":
            n"金莎拉满意地点了点头，小样本被试间设计应采用严格匹配法，且金莎拉已充分掌握了客户的信息"
            jump case3_q3
        "C.按到店顺序分为有自然知晓和无自然知晓":
            n"这样似乎会加入混淆变量"
            jump case3_q2

label case3_q3:
    scene bg case3 private at bg_full with fade
    n"VELORA 的私域传播变量，是通过男模在夜间私人陪伴场景中和富婆的对话来操作的。"
    n"一个男模会服务多个富婆且通常每晚只会服务一个富婆"
    n"金莎拉希望实验的操作能尽可能自然，以不让被试有所察觉和怀疑"
    n"因此，她决定花两周时间进行实验"
    n"为了有效比较“有无私域传播”的效果，最适合采用哪种控制方法？"
    menu:
        "A.区块随机法":
            n"金莎拉隐约觉得这不是最合适的方法"
            jump case3_q3
        "B.恒定法":
            n"恒定法似乎不能妥善解决此处的混淆变量"
            jump case3_q3
        "C.随机区组法":
            n"没错，这里应采用随机区组法"
            n"私域传播无法在同一天完成，实验会分散到不同日期。"
            n"工作日和周末、不同夜晚的状态和氛围可能不同，如果某一类条件集中安排在某些日期，结果就可能混入时间因素。"
            jump case3_q4
        "D.抵消平衡法":
            n"不对，私域传播变量是被试间变量"
            jump case3_q3

label case3_q4:
    scene bg case3 private at bg_full with fade
    n"实验结束后，金莎拉准备把规律用于芭朵奥推广。"
    n"这项实验很成功，她发现虽然自然知晓的主效应不显著，但私域传播的主效应和自然知晓与私域传播的交互作用都显著且有较大效应量。"
    n"但是从心理学实验设计的角度看，该实验存在的最大缺陷是："
    menu:
        "A.使用了同一个目标品牌，导致材料数量太少":
            n"这似乎并非实验的最大缺陷，使用同一个目标品牌本身是一种恒定处理"
            jump case3_q4
        "B.没有取得知情同意，存在实验伦理问题":
            n"没错，这项实验最大的局限是实验伦理问题。"
            jump case3_clear
        "C.没有让所有富太太都经历四种条件":
            n"被试间设计本身就不需要让被试经历多种条件"
            jump case3_q4
        "D. 实验的生态效度低":
            n"实际上，这个实验的生态效度很高"
            jump case3_q4

label case3_clear:
    scene bg case3 clear at bg_full with fade
    n"金莎拉终于明确了将芭朵奥真正打造成富人心中顶奢的路径。"
    n"白天，金莎拉让人以KOL身份在网上发帖：“最近一个很低调的欧洲顶奢品牌“芭朵奥”即将进入韩国市场。”"
    n"帖子不把话说满，只是让越来越多的人开始听说过芭朵奥这个品牌以及它的顶奢定位。"
    n"晚上，男模们再把这个品牌送进私人场景：“姐姐最近听过芭朵奥吗？”，“最近几个姐姐都在问。”"
    n"几轮之后，芭朵奥不再像一个刚出现的新品牌。"
    n"它开始变成富太太们口中那个：“网上好像很多人都提到过。”“圈里也有人提起。”“是不是很稀有？”“好像真正有钱有权的人都用的是芭朵奥包。”"
    jump chapter_4

label chapter_4:
    scene bg case4 presale at bg_full with fade
    n"金莎拉决定继续用 VELORA 做最后一场未上市新品样包预购活动。"
    n"她想研究：富太太愿意追逐一个包，到底是因为它的品质更高，还是因为它数量稀少、购买门槛高带来的身份优越感？"
    n"VELORA 不会真的上市销售。客户只能看样包，并决定是否愿意先登记，等待后续上市安排。"
    n"销售介绍结束后，会先停顿，观察客户是否主动询问购买方式。"
    n"如果客户没有主动提出，销售再统一问：“如果您感兴趣，我可以帮您先做登记，后续安排出来后再通知您。需要帮您登记吗？”"
    n"实验的因变量定为购买意愿强度，共有3个水平，当客户的反应是不登记时记为0，在销售询问后表示想要登记的记为1，主动询问购买路径并要求登记的记为2。"
    jump case4_q1

label case4_q1:
    scene bg case4 presale at bg_full with fade
    n"VELORA 的预售活动不能铺得太大。"
    n"金莎拉想同时考察三个自变量：产品品质（高 / 中）、数量稀缺性（低 / 高）和购买资格门槛（低 / 高）"
    n"产品品质通过给被试展示的包的原材料成本的高低来操控，数量稀缺性与购买资格门槛则以向客户介绍产品时所用的话语来操作，其中高购买资格门槛条件下登记后需通过客户购买资格的审核才能购买，低门槛则不需审核。"
    n"这个实验理论上最好用三因素被试间实验设计"
    n"但为了缩小预售活动的规模以免造成太大影响，金莎拉决定对其中一个变量采用被试内设计。"
    n"三个变量中最适合被试内设计的是："
    menu:
        "A.产品品质":
            n"金莎拉点了点头"
            n"产品品质可以让同一名客户先后接触两类样包来操作"
            jump case4_q2
        "B.数量稀缺性":
            n"品牌的数量稀缺性不可能一会稀缺一会不稀缺"
            jump case4_q1
        "C.购买资格门槛":
            n"同一个品牌的购买资格门槛应当统一，不能一会高一会低"
            jump case4_q1

label case4_q2:
    scene bg case4 presale at bg_full with fade
    n"金莎拉决定让每位客户都接触两类 VELORA 样包：一类为高品质，一类为中品质。"
    n"两类样包的外观风格、价格区间、展示时间和销售介绍方式都保持一致。"
    n"除了以上控制方法外，产品品质变量还需要采用的控制方法是："
    menu:
        "A.匹配法":
            n"金莎拉摇了摇头"
            jump case4_q2
        "B.抵消平衡法":
            n"产品品质在这里是被试内变量，同一位客户会先后接触高品质和中品质样包，因此需要控制呈现顺序,以避免“先看到哪一类包”系统性影响客户的购买意愿"
            jump case4_q3
        "C.随机区组法":
            n"金莎拉皱了皱眉"
            jump case4_q2
        "D.排除法":
            n"金莎拉摇了摇头"
            jump case4_q2

label case4_q3:
    scene bg case4 presale at bg_full with fade
    n"VELORA的预售活动根据稀缺性高低和购买门槛高低分为四个情境，每个被试会被安排到一个情境中。"
    n"同时，每位客户还会按不同的顺序先后看到高品质和中品质两类样包。"
    n"由于被试数量有限，不可能兼顾被试间变量的分组和被试内变量的顺序平衡分组。此时，以下最合理的实验安排原则是："
    menu:
        "A.只要总体上先看高品质样包和先看低品质样包的人数相等即可":
            n"问题并没有这么容易解决"
            jump case4_q3
        "B.先保证四种被试间销售情境中的客户分配尽量可比，再在各情境内平衡样包顺序":
            n"这是混合设计中的重要问题。当混合设计没有充足的被试时，先处理被试间分组，再处理被试内顺序平衡。"
            jump case4_q4
        "C.先保证产品品质的呈现顺序完全平衡，再尽可能均衡四种销售情境的人数":
            n"方法似乎有些问题"
            jump case4_q3
        "D.让销售随机决定进入哪种情境和先看哪只样包":
            n"小样本并不适合随机法"
            jump case4_q3

label case4_q4:
    scene bg case4 presale at bg_full with fade
    n"VELORA 预售活动结束后，金莎拉整理了不同条件下客户的平均购买意愿强度，并将数据绘制成折现图。"
    show screen case4_interaction_screen
    n"请根据图形判断，下列哪些交互作用存在？"
    menu:
        "A.产品品质 × 数量稀缺性":
            hide screen case4_interaction_screen
            n"还是需要重新解读一下图表"
            jump case4_q4
        "B. 产品品质 × 购买资格门槛":
            hide screen case4_interaction_screen
            n"还是需要重新解读一下图表"
            jump case4_q4
        "C. 数量稀缺性 × 购买资格门槛":
            hide screen case4_interaction_screen
            n"没错，同样的稀缺性差异，在不同门槛条件下产生了不同的购买意愿变化"
            jump case4_q5
        "D. 产品品质 × 数量稀缺性 × 购买资格门槛":
            hide screen case4_interaction_screen
            n"还是需要再重新解读一下图表"
            jump case4_q4

label case4_q5:
    scene bg case4 presale at bg_full with fade
    n"助手看完结果后兴奋地说:"
    aide"既然产品品质没有明显主效应，那以后芭朵奥根本不用在意材料和做工。"
    aide"只要制造稀缺和购买门槛，就能成为顶奢。"
    n"从实验设计角度看，金莎拉最应该指出这个结论的问题是："
    menu:
        "A.内部效度问题":
            n"这个结论的错误之处不在于内部效度"
            jump case4_q5
        "B.外部效度问题":
            n"本实验中的“中品质”不是低劣产品，而是：有设计感、质感过关、只是没有使用最高成本材料和最顶级工艺。"
            n"所以“产品品质没有明显主效应”只能限定在这个范围内理解：当产品本身不差时，更高的品质配置未必比稀缺性和购买门槛更重要。"
            n"但这个结论不能推广成：任何粗糙、廉价、明显低质的包都能靠稀缺和门槛成为顶奢。"
            n"如果产品品质低到破坏基本质感，消费者很可能不会接受它作为奢侈品。"
            n"因此，芭朵奥不必追求最高成本配置，但必须守住设计感和基本品质底线。"
            jump case4_clear
        "C.信度问题":
            n"这个结论的错误之处不在于信度"
            jump case4_q5

label case4_clear:
    scene bg case4 presale at bg_full with fade
    n"金莎拉合上 VELORA 的档案，轻声说：“品质不能缺席。”“但品质只是入场券。”“真正的王冠，要戴在规则上。”"
    n"于是，VELORA 被封存。它只是试验品牌，负责告诉金莎拉：富太太追逐的并不只是包本身，而是拥有它所代表的位置。"
    scene bg case4 clear at bg_full with fade
    n"芭朵奥正式开业的那晚，整条街都洒满了香槟色灯光"
    n"巨大的Bardoir招牌悬在门楣之上。红毯从店门一路扑向街边，黑色礼车停满道路"
    n"KOL、媒体、贵宾和受邀客户都能看见芭朵奥的名字，也都能拍下它的影子。但不是所有人都能拥有它。"
    n"展柜里只放出少数样包。销售不会直接询问客户是否付款，而是温柔地告诉她们：“首批数量很少。”，“每只包都有独立编号。”，“如果您感兴趣，可以先留下登记。”，“后续名单确认后，会单独通知。”"
    n"有人问：“登记以后就可以买了吗？”，销售只是微笑：“登记只是第一步。”，“芭朵奥会为每一只包确认合适的主人。”"
    n"很快，客人们开始追问：“首批到底有多少只？”，“需要介绍人吗？”，“如果这次没有进入名单，下一批还有机会吗？”，“能不能先帮我保留一个编号？”"
    n"金莎拉站在二楼,看着人群、闪光灯和低声交谈的富人们"
    n"她终于不再站在别人的橱窗外奢望遥不可及的梦想"
    n"这一次，众人仰望的品牌，由她亲手创造"
return
